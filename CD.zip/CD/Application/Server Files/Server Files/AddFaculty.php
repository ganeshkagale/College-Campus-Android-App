<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $name = $_POST['name'];
		 $email = $_POST['email'];
		 $details = $_POST['details'];
		 $staff = $_POST['staff'];

         $sql = "SELECT staff_dept from stafftbl where staff_username='$staff'";       
         $result = $con->query($sql);
         $row = $result->fetch_assoc();
         $dept = $row['staff_dept'];

		
		 $sql = "SELECT faculty_id FROM facultytbl WHERE faculty_dept='$dept'";
		 $result = $con->query($sql);
		 $id = 0;
         while($row = $result->fetch_assoc()) {
            $id =  $row['faculty_id'];                
          }             
         $id=$id+1;
		 
		 $Sql_Query = "INSERT INTO facultytbl (faculty_id,faculty_name,faculty_email,faculty_details,faculty_dept) values ($id,'$name','$email','$details','$dept')";		
			if(mysqli_query($con,$Sql_Query))
			{
				 echo 'Registered Successfully';
			}
			else
			{
				 echo 'Registration Error';
		 	}
		 

		 mysqli_close($con);
	}
		
		
?>
	
