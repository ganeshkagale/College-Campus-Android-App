<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $username = $_POST['username'];
		 
		 $sql = "SELECT staff_dept FROM stafftbl WHERE staff_username='$username'";
	     $result = $con->query($sql);
	     $row = $result->fetch_assoc();
         $dept = $row['staff_dept'];

		 $sql = "Select studentsection_topic , studentsection_details,studentsection_student From studentsectiontbl where studentsection_dept = '$dept'";
	     $result1 = $con->query($sql);
		 $data = "";
		 if ($result1->num_rows > 0) 
		 {
			  while($row = $result1->fetch_assoc()) 
			  {
						$topic = $row['studentsection_topic'];
		                $details = $row['studentsection_details'];
                		$student = $row['studentsection_student'];
		                $data = $data . $topic . "#" . $details . "#" . $student . "-";
				
			  }
  		 }		 
		 echo $data;
		 mysqli_close($con);
		
	
	}

?>