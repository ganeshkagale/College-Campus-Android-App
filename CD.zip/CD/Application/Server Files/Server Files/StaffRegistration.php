<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $username = $_POST['username'];
		 $password = $_POST['password'];
		 $fullname = $_POST['fullname'];
		 $email = $_POST['email'];
		 $dept = $_POST['dept'];
		
		 $CheckSQL = "SELECT * FROM stafftbl WHERE staff_username='$username'";
		 $check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
		 
		 if(isset($check)){
		
		 	echo 'UserName Already Exist';
		
		 }
		else
		{ 
			$Sql_Query = "INSERT INTO stafftbl (staff_username,staff_password,staff_fullname,staff_email , staff_dept) values ('$username','$password','$fullname','$email','$dept')";
		
			 if(mysqli_query($con,$Sql_Query))
			{
				 echo 'Registered Successfully';
			}
			else
			{
				 echo 'Registration Error';
		 	}
		 }

		 mysqli_close($con);
	}
		
		
?>
	
