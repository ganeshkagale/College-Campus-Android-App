<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $username = $_POST['username'];
		 $password = $_POST['password'];
		 
		 $CheckSQL = "SELECT * FROM stafftbl WHERE staff_username='$username' and staff_password = '$password'";
		 $check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
		 
		 if(isset($check))
		{
		
		 	echo 'Success';
		
		 }
		else
		{ 
			
		 	echo 'Error';
		 
		 
		}
		 mysqli_close($con);
		
	
	}

?>