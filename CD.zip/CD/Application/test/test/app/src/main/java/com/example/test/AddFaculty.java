package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

public class AddFaculty extends AppCompatActivity {

    TextInputEditText txtFullName , txtEmail;
    EditText txtDetails ;
    Button reg;


    public void executeTask()
    {
        txtFullName = findViewById(R.id.faculty_fullname);
        txtEmail = findViewById(R.id.faculty_email);
        txtDetails = findViewById(R.id.faculty_details);


        String fullname = String.valueOf(txtFullName.getText());
        String email = String.valueOf(txtEmail.getText());
        String details = String.valueOf(txtDetails.getText());
        String dept = UTIL.staffusername;

        String url = "https://"+ UTIL.serverip+"//AddFaculty.php";
        HashMap<String,String> postData = new HashMap<String,String>();
        postData.put("name", fullname);
        postData.put("email", email);
        postData.put("details", details);
        postData.put("staff",dept);

        new RequestHandler(this,url,postData).execute();


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_faculty);


        reg = findViewById(R.id.faculty_buttonSignUp);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (UTIL.staffusername.length()==0) {
                    Toast.makeText(getApplicationContext(), "LogIn First!!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Staff_Login.class);
                    startActivity(intent);
                }
                else
                executeTask();
            }
        });


    }
}