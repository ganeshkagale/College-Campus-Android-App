package com.example.test;

public class FacultyView {

    private String fname;
    private String femail;

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setFemail(String femail) {
        this.femail = femail;
    }

    public void setFdetails(String fdetails) {
        this.fdetails = fdetails;
    }

    private String fdetails;

    public FacultyView(String fname, String femail, String fdetails) {
        this.fname = fname;
        this.femail = femail;
        this.fdetails = fdetails;
    }

    public String getFname() {
        return fname;
    }

    public String getFemail() {
        return femail;
    }

    public String getFdetails() {
        return fdetails;
    }
}
