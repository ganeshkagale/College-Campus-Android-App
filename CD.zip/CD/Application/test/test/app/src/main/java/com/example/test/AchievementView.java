package com.example.test;

public class AchievementView {
    private String topic,details;

    public AchievementView(String topic, String link) {
        this.topic = topic;
        this.details = link;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String link) {
        this.details = link;
    }
}
