<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $blog = $_POST['blog'];
		 $topic = $_POST['topic'];		 
		 $staff = $_POST['staff'];

         $sql = "SELECT staff_dept from stafftbl where staff_username='$staff'";       
         $result = $con->query($sql);
         $row = $result->fetch_assoc();
         $dept = $row['staff_dept'];

		
		 
		 
		 $Sql_Query = "INSERT INTO blogtbl (blog_topic,blog_details,blog_dept) values ('$topic','$blog','$dept')";		
			if(mysqli_query($con,$Sql_Query))
			{
				 echo 'Data Added Successfully';
			}
			else
			{
				 echo 'Error';
		 	}
		 

		 mysqli_close($con);
	}
		
		
?>
	
