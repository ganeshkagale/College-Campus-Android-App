<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $username = $_POST['username'];
		 
		 $sql = "SELECT User_Dept FROM studenttbl WHERE user_name='$username'";
	     $result = $con->query($sql);
	     $row = $result->fetch_assoc();
         $dept = $row['User_Dept'];

		 $sql = "Select faculty_name , faculty_email,faculty_details From facultytbl where faculty_dept = '$dept'";
	     $result1 = $con->query($sql);
		 $data = "";
		 if ($result1->num_rows > 0) 
		 {
			  while($row = $result1->fetch_assoc()) 
			  {
				$faculty_name = $row['faculty_name'];
		                $faculty_email = $row['faculty_email'];
                		$faculty_details = $row['faculty_details'];
		                $data = $data . $faculty_name . "#" . $faculty_email . "#" . $faculty_details . "-";
				
			  }
  		 }		 
		 echo $data;
		 mysqli_close($con);
		
	
	}

?>