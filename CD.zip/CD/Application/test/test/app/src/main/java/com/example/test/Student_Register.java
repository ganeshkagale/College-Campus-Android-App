package com.example.test;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;



public class Student_Register extends AppCompatActivity {

    TextView student_signup_logintext;
    TextInputEditText textInputEditTextFullname, textInputEditTextUsername, textInputEditTextPassword, textInputEditTextEmail;
    Button student_signup_buttonSignUp;
    ProgressBar progressBar;
    Spinner dept;


    private static class HTTPReqTask extends AsyncTask<String, Void, String> {

        Context context;

        public HTTPReqTask(Context cpm)
        {
            context=cpm;
        }

        @Override
        protected void onPostExecute(String s)
        {

            if ( s != null ) {
                Log.i("data", s);
                Toast.makeText(context, s ,   Toast.LENGTH_SHORT).show();
            }
            else
                Log.i("data", "Some Error");

        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            String rline = null;
            try {

                HashMap<String, String> postData = new HashMap<>();
                String surl = "https://"+ UTIL.serverip+"//UserRegistration.php";
                UTIL.trustAllCertificates();
                postData.put("username", params[0]);
                postData.put("password", params[1]);
                postData.put("fullname", params[2]);
                postData.put("email", params[3]);
                postData.put("dept", params[4]);
                StringBuilder sbParams = new StringBuilder();
                int i = 0;
                for (String key : postData.keySet()) {
                    try {
                        if (i != 0){
                            sbParams.append("&");
                        }
                        sbParams.append(key).append("=")
                                .append(URLEncoder.encode(postData.get(key), "UTF-8"));

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
                String paramsString = sbParams.toString();

                URL url = new URL(surl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Accept-Charset", "UTF-8");
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                urlConnection.setChunkedStreamingMode(0);

                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        out, "UTF-8"));
                writer.write(paramsString);
                writer.flush();

                int code = urlConnection.getResponseCode();
                //if (code !=  201) {
                  //  throw new IOException("Invalid response from server: " + code);
                //}

                BufferedReader rd = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream()));
                String line = "";
                while ((line = rd.readLine()) != null) {
                    rline = line;
                    Log.i("data", line);


                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return rline;
        }

    }

    public void executeTask()
    {
        Log.i("info","Inside student signup");
        String student_fullname,student_username,student_email,student_password;
        student_fullname = String.valueOf(textInputEditTextFullname.getText());
        student_username = String.valueOf(textInputEditTextUsername.getText());
        student_email = String.valueOf(textInputEditTextEmail.getText());
        student_password = String.valueOf(textInputEditTextPassword.getText());
        Spinner spinner = (Spinner)findViewById(R.id.spinner2);
        String dept = spinner.getSelectedItem().toString();

        new HTTPReqTask(this).execute(student_username,student_password,student_fullname,student_email,dept);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_register);

        student_signup_logintext=findViewById(R.id.student_signup_loginText);
        textInputEditTextFullname=findViewById(R.id.student_signup_fullname);
        textInputEditTextUsername=findViewById(R.id.student_signup_username);
        textInputEditTextPassword=findViewById(R.id.student_signup_password);
        textInputEditTextEmail=findViewById(R.id.student_signup_email);
        student_signup_buttonSignUp=findViewById(R.id.student_signup_buttonSignUp);
        progressBar=findViewById(R.id.student_signup_progress);


        String dept[] = {"Department","Computer Engineering","Mechanical Engineering","Electronics Engineering"};
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,dept);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spin = findViewById(R.id.spinner2);
        spin.setAdapter(aa);





        student_signup_logintext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),Student_Login.class);
                startActivity(intent);
            }
        });

        //        on click listner on button



        student_signup_buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                executeTask();
            }
        });
    }
}