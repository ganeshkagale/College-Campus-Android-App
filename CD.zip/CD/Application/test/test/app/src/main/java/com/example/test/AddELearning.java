package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;

public class AddELearning extends AppCompatActivity {

    TextInputEditText topic , link;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_elearning);
        save = findViewById(R.id.elearn_buttonSignUp);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (UTIL.staffusername.length()==0) {
                    Toast.makeText(getApplicationContext(), "LogIn First!!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Staff_Login.class);
                    startActivity(intent);
                }
                else
                    executeTask();
            }
        });

    }

    public void executeTask()
    {
        topic = findViewById(R.id.elearning_topic);
        link = findViewById(R.id.elarning_link);


        String topictext = String.valueOf(topic.getText());
        String linktext = String.valueOf(link.getText());
        String dept = UTIL.staffusername;

        String url = "https://"+ UTIL.serverip+"//AddELearning.php";
        HashMap<String,String> postData = new HashMap<String,String>();
        postData.put("link", topictext);
        postData.put("topic", linktext);
        postData.put("staff",dept);

        new RequestHandler(this,url,postData).execute();


    }
}