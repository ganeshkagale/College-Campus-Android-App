package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

public class Staff extends AppCompatActivity {

    TextView add_notice,add_faculty,add_elearning,add_blog,views_student_Section,logout,add_achievement;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);
        add_notice=findViewById(R.id.add_notice);
        add_faculty = findViewById(R.id.addfaculty);
        add_elearning = findViewById(R.id.addelearning);
        add_blog = findViewById(R.id.addblog);
        logout = findViewById(R.id.txtLogOut);
        add_achievement = findViewById(R.id.addachievement);
        views_student_Section = findViewById(R.id.viewstudentsection);


//        add_achievement.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                UTIL.staffusername="";
//                Toast.makeText(getApplicationContext(), "Logged Out Successfully!!" ,   Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(getApplicationContext(),AddAchivement.class);
//                startActivity(intent);
//            }
//        });

        add_achievement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),AddAchivement.class);
                startActivity(intent);
            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UTIL.staffusername="";
                Toast.makeText(getApplicationContext(), "Logged Out Successfully!!" ,   Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),Staff_Login.class);
                startActivity(intent);
            }
        });



        add_blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AddPlacementBlog.class);
                startActivity(intent);
            }
        });

        views_student_Section.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ViewStudentSection.class);
                startActivity(intent);
            }
        });
        add_notice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),add_notice.class);
                startActivity(intent);
            }
        });
        add_faculty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AddFaculty.class);
                startActivity(intent);
            }
        });

        add_elearning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AddELearning.class);
                startActivity(intent);
            }
        });
    }
}