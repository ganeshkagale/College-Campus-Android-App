package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewElearning extends AppCompatActivity {

    ListView lv ;
    private static class ViewElearningTask extends AsyncTask<String, Void, String> {

        Context context;
        String username="";
        ListView lv ;
        public ViewElearningTask(Context cpm,ListView lv )
        {
            context=cpm;
            this.lv=lv;
        }

        @Override
        protected void onPostExecute(String s)
        {

            if ( s != null ) {
                Log.i("data", s);
                if (s.equalsIgnoreCase("Error")) {
                    Toast.makeText(context, "ERROR ", Toast.LENGTH_SHORT).show();
                } else {
                    //Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
                    String data[]= s.split("-");
                    final ArrayList<LearningView> arrayList = new ArrayList<LearningView>();

                    for(int i = 0 ; i < data.length ; i++)
                    {
                        String d = data[i];
                        String t[] = d.split("#");
                        Log.i("data", d);
                        arrayList.add(new LearningView(t[0], t[1]));

                    }


                    LearningViewAdapter fd = new LearningViewAdapter(context,arrayList);
                    lv.setAdapter(fd);
                }
            }
            else
                Log.i("data", "Some Error");

        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            String rline = null;
            try {
                Log.i("data", "line");
                HashMap<String, String> postData = new HashMap<>();
                String surl = "https://"+ UTIL.serverip+"//GetELearning.php";
                UTIL.trustAllCertificates();
                postData.put("username", UTIL.studentusername);
                StringBuilder sbParams = new StringBuilder();
                int i = 0;
                for (String key : postData.keySet()) {
                    try {
                        if (i != 0){
                            sbParams.append("&");
                        }
                        sbParams.append(key).append("=")
                                .append(URLEncoder.encode(postData.get(key), "UTF-8"));

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
                String paramsString = sbParams.toString();

                URL url = new URL(surl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Accept-Charset", "UTF-8");
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                urlConnection.setChunkedStreamingMode(0);

                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        out, "UTF-8"));
                writer.write(paramsString);
                writer.flush();

                int code = urlConnection.getResponseCode();
                //if (code !=  201) {
                //  throw new IOException("Invalid response from server: " + code);
                //}

                BufferedReader rd = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream()));
                String line = "";
                while ((line = rd.readLine()) != null) {
                    rline = line;
                    Log.i("data", line);


                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return rline;
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_elearning);
        lv = findViewById(R.id.learninglistView);
        executeTask();

    }
    public void executeTask()
    {
        new ViewElearningTask(this,lv).execute();
    }
}