package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

public class Student extends AppCompatActivity {

    TextView view_notice,view_faculty,view_learning,add_student,view_achivements,view_placement;
    TextView logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        view_notice = findViewById(R.id.view_notice);
        view_faculty = findViewById(R.id.view_faculty);
        view_learning = findViewById(R.id.view_learning);
        add_student = findViewById(R.id.student_section);
        view_achivements = findViewById(R.id.view_achievements);
        view_placement = findViewById(R.id.view_placementblog);
        logout = findViewById(R.id.txtLogOut);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UTIL.studentusername="";
                Toast.makeText(getApplicationContext(), "Logged Out Successfully!!" ,   Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),Staff_Login.class);
                startActivity(intent);
            }
        });

        view_achivements.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ViewAchievement.class);
                startActivity(intent);
            }
        });
        view_placement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ViewBlog.class);
                startActivity(intent);
            }
        });

        view_notice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getNoticeID();
            }
        });

        view_faculty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ViewFaculty.class);
                startActivity(intent);
            }
        });

        add_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),AddStudentSection.class);
                startActivity(intent);
            }
        });

        view_learning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ViewElearning.class);
                startActivity(intent);
            }
        });
    }

    void getNoticeID()
    {
        new HTTPLoginTask(this).execute(UTIL.studentusername);
    }
    private static class HTTPLoginTask extends AsyncTask<String, Void, String> {

        Context context;
        String username ;

        public HTTPLoginTask(Context cpm)
        {
            context=cpm;
        }

        @Override
        protected void onPostExecute(String s)
        {

            if ( s != null ) {
                Log.i("data", s);
                UTIL.noticeid = s;
                Toast.makeText(context, s ,   Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context,ViewNotice.class);
                context.startActivity(intent);

            }
            else
                Log.i("data", "Some Error");

        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            String rline = null;
            try {

                HashMap<String, String> postData = new HashMap<>();
                String surl = "https://"+ UTIL.serverip+"//GetNoticeID.php";
                UTIL.trustAllCertificates();
                postData.put("username", params[0]);

                StringBuilder sbParams = new StringBuilder();
                int i = 0;
                for (String key : postData.keySet()) {
                    try {
                        if (i != 0){
                            sbParams.append("&");
                        }
                        sbParams.append(key).append("=")
                                .append(URLEncoder.encode(postData.get(key), "UTF-8"));

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
                String paramsString = sbParams.toString();

                URL url = new URL(surl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Accept-Charset", "UTF-8");
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                urlConnection.setChunkedStreamingMode(0);

                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        out, "UTF-8"));
                writer.write(paramsString);
                writer.flush();

                int code = urlConnection.getResponseCode();
                //if (code !=  201) {
                //  throw new IOException("Invalid response from server: " + code);
                //}

                BufferedReader rd = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream()));
                String line = "";
                while ((line = rd.readLine()) != null) {
                    rline = line;
                    Log.i("data", line);


                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return rline;
        }

    }
}