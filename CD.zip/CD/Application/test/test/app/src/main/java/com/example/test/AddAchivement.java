package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;

public class AddAchivement extends AppCompatActivity {

    Button save;
    TextInputEditText topic;
    EditText link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_achivement);
        save = findViewById(R.id.elearn_buttonSignUp);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (UTIL.staffusername.length()==0) {
                    Toast.makeText(getApplicationContext(), "LogIn First!!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Staff_Login.class);
                    startActivity(intent);
                }
                else
                executeTask();
            }
        });
    }
    public void executeTask()
    {
        topic = findViewById(R.id.achivementtopic);
        link = findViewById(R.id.achivement_details);


        String topictext = String.valueOf(topic.getText());
        String blogtext = String.valueOf(link.getText());
        String dept = UTIL.staffusername;

        String url = "https://"+ UTIL.serverip+"//AddAchievement.php";
        HashMap<String,String> postData = new HashMap<String,String>();
        postData.put("topic", topictext);
        postData.put("blog", blogtext);
        postData.put("staff",dept);

        new RequestHandler(this,url,postData).execute();


    }
}