package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class GuestView extends AppCompatActivity {

        TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_view);
        textView = (TextView) findViewById(R.id.textView);
        String para = "The Tatyasaheb Kore Institute of Engineering & Technology (abbreviated TKIET), (An Autonomous Institute) established in 1983, offers courses in Computer science and engineering, Mechanical engineering, Chemical engineering, Civil engineering and Electronics & Telecommunications engineering in UG and Mechanical engineering, Civil engineering and Electronics & Telecommunication engineering for PG level. TKIET is recognized by the government of Maharashtra, and is approved by the All India Council of Technical Education,[1] New Delhi. It is accredited by the National Board of Accreditation (NBA), New Delhi. In year 2016 the institute was accredited by NAAC 'A' grade with CGPA 3.27 which is highest in Shivaji University. The Institute is affiliated with Shivaji University, Kolhapur.";
        textView.setText(para);
        textView.setMovementMethod(new ScrollingMovementMethod());
    }
}