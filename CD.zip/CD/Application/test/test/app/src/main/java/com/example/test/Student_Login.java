package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

public class Student_Login extends AppCompatActivity {

    TextView student_login_signUptext;
    TextInputEditText textInputEditTextUsername, textInputEditTextPassword;
    Button student_login_buttonLogin;
    TextView textViewLSignUp,guest;
    ProgressBar progressBar;


    private static class HTTPLoginTask extends AsyncTask<String, Void, String> {

        Context context;
        String username="";
        public HTTPLoginTask(Context cpm)
        {
            context=cpm;
        }

        @Override
        protected void onPostExecute(String s)
        {

            if ( s != null ) {
                Log.i("data", s);
                if (s.equalsIgnoreCase("Error")) {
                    Toast.makeText(context, "Wrong Username / Password ", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
                    UTIL.studentusername = username;
                    Intent intent = new Intent(context, Student.class);
                    context.startActivity(intent);
                }
            }
            else
                Log.i("data", "Some Error");

        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            String rline = null;
            try {
                Log.i("data", "line");
                HashMap<String, String> postData = new HashMap<>();
                String surl = "https://"+ UTIL.serverip+"//UserLogin.php";
                UTIL.trustAllCertificates();
                postData.put("username", params[0]);
                postData.put("password", params[1]);
                username = params[0];
                Log.i("data", "lll");
                StringBuilder sbParams = new StringBuilder();
                int i = 0;
                for (String key : postData.keySet()) {
                    try {
                        if (i != 0){
                            sbParams.append("&");
                        }
                        sbParams.append(key).append("=")
                                .append(URLEncoder.encode(postData.get(key), "UTF-8"));

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
                String paramsString = sbParams.toString();

                URL url = new URL(surl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Accept-Charset", "UTF-8");
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                urlConnection.setChunkedStreamingMode(0);

                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        out, "UTF-8"));
                writer.write(paramsString);
                writer.flush();

                int code = urlConnection.getResponseCode();
                //if (code !=  201) {
                //  throw new IOException("Invalid response from server: " + code);
                //}

                BufferedReader rd = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream()));
                String line = "";
                while ((line = rd.readLine()) != null) {
                    rline = line;
                    Log.i("data", line);


                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return rline;
        }

    }

    public void executeTask()
    {
        Log.i("info","Inside student signup");
        textInputEditTextUsername=findViewById(R.id.student_login_usernameLogin);
        textInputEditTextPassword=findViewById(R.id.student_login_passwordLogin);
        String username = String.valueOf(textInputEditTextUsername.getText());
        String password = String.valueOf(textInputEditTextPassword.getText());

        new Student_Login.HTTPLoginTask(this).execute(username,password);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        guest = findViewById(R.id.student_login_guesttext_textView3);
        student_login_signUptext=findViewById(R.id.student_login_signUpText);
        textInputEditTextUsername=findViewById(R.id.student_login_usernameLogin);
        textInputEditTextPassword=findViewById(R.id.student_login_passwordLogin);
        student_login_buttonLogin=findViewById(R.id.student_login_buttonLogin);
        textViewLSignUp=findViewById(R.id.student_login_signUpText);
        progressBar=findViewById(R.id.student_login_progress);

        student_login_buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                executeTask();
            }
        });

        guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),GuestView.class);
                startActivity(intent);
            }
        });


        student_login_signUptext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Student_Register.class);
                startActivity(intent);
            }
        });

    }
}