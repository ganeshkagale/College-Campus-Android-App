package com.example.test;

public class StudentSectionView {
    private String topic,details,student;

    public StudentSectionView(String topic, String link,String student) {
        this.topic = topic;
        this.details = link;
        this.student = student;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String link) {
        this.details = link;
    }

    public String getStudent() {
        return student;
    }

    public void setStudent(String student) {
        this.student = student;
    }
}
