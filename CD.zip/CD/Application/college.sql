-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2022 at 03:57 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievementtbl`
--

CREATE TABLE `achievementtbl` (
  `achievement_topic` varchar(1000) NOT NULL,
  `achievement_details` varchar(1000) NOT NULL,
  `achievement_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `achievementtbl`
--

INSERT INTO `achievementtbl` (`achievement_topic`, `achievement_details`, `achievement_dept`) VALUES
('demo', 'demo', 'Computer Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `blogtbl`
--

CREATE TABLE `blogtbl` (
  `blog_topic` varchar(100) NOT NULL,
  `blog_details` varchar(1000) NOT NULL,
  `blog_dept` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `elearningtbl`
--

CREATE TABLE `elearningtbl` (
  `id` int(11) NOT NULL,
  `elearning_link` varchar(1000) NOT NULL,
  `elearning_topic` varchar(1000) NOT NULL,
  `elearning_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `elearningtbl`
--

INSERT INTO `elearningtbl` (`id`, `elearning_link`, `elearning_topic`, `elearning_dept`) VALUES
(1, 'demo', 'demo', 'Computer Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `facultytbl`
--

CREATE TABLE `facultytbl` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(1000) NOT NULL,
  `faculty_email` varchar(1000) NOT NULL,
  `faculty_details` varchar(1000) NOT NULL,
  `faculty_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `imagetable`
--

CREATE TABLE `imagetable` (
  `image_id` int(11) NOT NULL,
  `image_title` varchar(1000) NOT NULL,
  `image_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stafftbl`
--

CREATE TABLE `stafftbl` (
  `staff_username` varchar(1000) NOT NULL,
  `staff_password` varchar(1000) NOT NULL,
  `staff_fullname` varchar(1000) NOT NULL,
  `staff_email` varchar(1000) NOT NULL,
  `staff_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stafftbl`
--

INSERT INTO `stafftbl` (`staff_username`, `staff_password`, `staff_fullname`, `staff_email`, `staff_dept`) VALUES
('amol', 'amol', 'amol\n', 'amol', 'Computer Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `studentsectiontbl`
--

CREATE TABLE `studentsectiontbl` (
  `studentsection_topic` varchar(1000) NOT NULL,
  `studentsection_details` varchar(1000) NOT NULL,
  `studentsection_student` varchar(1000) NOT NULL,
  `studentsection_dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentsectiontbl`
--

INSERT INTO `studentsectiontbl` (`studentsection_topic`, `studentsection_details`, `studentsection_student`, `studentsection_dept`) VALUES
('demo', 'demo', 'sid', 'Computer Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `studenttbl`
--

CREATE TABLE `studenttbl` (
  `User_Name` varchar(1000) NOT NULL,
  `User_Pass` varchar(1000) NOT NULL,
  `User_FullName` varchar(1000) NOT NULL,
  `User_Email` varchar(1000) NOT NULL,
  `User_Dept` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studenttbl`
--

INSERT INTO `studenttbl` (`User_Name`, `User_Pass`, `User_FullName`, `User_Email`, `User_Dept`) VALUES
('sid', 'sid', 'sid', 'sid', 'Computer Engineering');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
