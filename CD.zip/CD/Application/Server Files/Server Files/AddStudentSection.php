<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $topic = $_POST['topic'];
		 $details = $_POST['details'];		 
		 $student = $_POST['student'];

         $sql = "SELECT user_dept from studenttbl where user_name='$student'";       
         $result = $con->query($sql);
         $row = $result->fetch_assoc();
         $dept = $row['user_dept'];

		
		 
		 $Sql_Query = "INSERT INTO studentsectiontbl ( studentsection_topic,studentsection_details,studentsection_student,  ) values ('$topic','$details','$student','$dept')";		
			if(mysqli_query($con,$Sql_Query))
			{
				 echo 'Data Added Successfully';
			}
			else
			{
				 echo 'Error';
		 	}
		 

		 mysqli_close($con);
	}
		
		
?>
	
