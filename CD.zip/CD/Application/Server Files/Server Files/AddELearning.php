<?php 

	if($_SERVER['REQUEST_METHOD']=='POST')
	{

		//Define your host here.
		$HostName = "localhost";
		//Define your database username here.
		$HostUser = "root";
		//Define your database password here.
		$HostPass = "";
		//Define your database name here.
		$DatabaseName = "college";	
		
		 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
		
		 $link = $_POST['link'];
		 $topic = $_POST['topic'];		 
		 $staff = $_POST['staff'];

         $sql = "SELECT staff_dept from stafftbl where staff_username='$staff'";       
         $result = $con->query($sql);
         $row = $result->fetch_assoc();
         $dept = $row['staff_dept'];

		
		 $sql = "SELECT id FROM elearningtbl  WHERE elearning_dept='$dept'";
		 $result = $con->query($sql);
		 $id = 0;
         while($row = $result->fetch_assoc()) {
            $id =  $row['id'];                
          }             
         $id=$id+1;
		 
		 $Sql_Query = "INSERT INTO elearningtbl (id,elearning_link,elearning_topic,elearning_dept) values ($id,'$link','$topic','$dept')";		
			if(mysqli_query($con,$Sql_Query))
			{
				 echo 'Data Added Successfully';
			}
			else
			{
				 echo 'Error';
		 	}
		 

		 mysqli_close($con);
	}
		
		
?>
	
